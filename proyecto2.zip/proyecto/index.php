<?php
header("Location:html/index.html");
?>