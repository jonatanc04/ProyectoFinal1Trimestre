let loginBtn = document.getElementById("login");
let registerBtn = document.getElementById("regis");
let alerta = document.getElementById("mensaje");

let formSesion = document.getElementById("conSesion");
let calendar = document.getElementById("conCalendar");

let userList = JSON.parse(localStorage.getItem("listaUsuarios"));
let usuario;
let intervalo;

const crearUsuario = (usuario, password) => ({
    usuario: usuario,
    password: password
});

const terminarAlerta = () => {
    alerta.innerHTML = "";
    clearInterval(intervalo);
}

const incioAlerta = mensaje => {
    clearInterval(intervalo);
    alerta.innerHTML = mensaje;
    intervalo = setInterval(() => terminarAlerta(), 4000);
};

loginBtn.addEventListener("click", () => {

    let user = document.getElementById("user").value;
    let pwd = document.getElementById("pass").value;

    if (user == "" || pwd == "") {
        incioAlerta("No puedes dejar campos vacíos");
    } else {
        if (!userList) {
            incioAlerta("No existen usuarios registrados");
        } else {
            usuario = userList.filter(
                (Usuario) => Usuario.usuario == user
            );
    
            if(usuario[0] == undefined) {
                incioAlerta("No existen usuarios con ese nombre");
            } else {
                if (usuario[0].password == pwd) {

                    console.log("Sesión correcta");
                    
                } else {
                    incioAlerta("La contraseña introducida no es correcta");
                }
            }
        }
    }

});

registerBtn.addEventListener("click", () => {

    if (!userList) {
        userList = [];
    }

    let user = document.getElementById("user").value;
    let pwd = document.getElementById("pass").value;;

    if (user == "" || pwd == "") {
        incioAlerta("No puedes dejar campos vacíos");
    } else {
        let existeUsuario = userList.some(o => o.usuario === user);
        if (existeUsuario) {
            incioAlerta("Nombre de usuario no disponible");
        } else {
            userList.push(crearUsuario(user, pwd));
            localStorage.setItem("listaUsuarios", JSON.stringify(userList));
        }
    }

});