var formulario = document.getElementById('formulario');
var respuesta = document.getElementById('respuesta');

/*

    Este es el motor principal de la página web, el cual detecta si estamos
    realizando un log in, en este caso hace una petición get para validar
    al cliente, y por otro lado realiza una petición post en el caso de que
    nos estemos registrando.

*/

formulario.addEventListener('submit', function(e) {
    e.preventDefault();
    var datos = new FormData(formulario);

    var nombre = datos.get('nombre');
    var dniCliente = datos.get('dniCliente');
    var email = datos.get('email');
    var pwd = datos.get('pwd');

    var idCarrito = obtenerIdCarrito();

    if (nombre === '' && email === '') {
        const queryString = "dniCliente=" + dniCliente + "&pwd=" + pwd;

        fetch("../sClientes/validarClientes.php?" + queryString, {
            method: 'GET',
        })
        .then(res => {
            return res.json();
        })
        .then(data => {
            console.log(data);
                if (data === false) {
                    alert("Se ha producido un error en la validación del cliente.");
                } else {
                    console.log(idCarrito);
                    if (idCarrito !== null) {
                        actualizarCarrito(idCarrito, dniCliente);
                    }
                    setTimeout(function () {
                        window.location.href = "../view/index.php";
                    }, 1000);
                }
        })
        .catch(error => {
            console.error(error);
        });
        
    } else {
        if (nombre === '' || dniCliente === '' || email === '' || pwd === '') {
            alert("Existen campos vacíos. Por favor, completa todos los campos.");
        } else {
            fetch('../sClientes/validarClientes.php', {
                method: 'POST',
                body: datos
            })
            .then(res => {
                if (!res.ok) {
                    alert("Esa cuenta ya está en uso. Utilice otra información.");
                }
                return res.json();
            })
            .then(data => {
                console.log(data);
                if (data !== false) {
                    if (idCarrito !== null) {
                        actualizarCarrito(idCarrito, dniCliente);
                    }
                    setTimeout(function () {
                        window.location.href = "../view/index.php";
                    }, 1000);
                }
            })
            .catch(error => {
                console.error(error);
            });
        }
    }
});

// Esta función se encarga de añadir el DNI del Cliente al carrito cuando este se registra / loguea

function actualizarCarrito(idCarrito, dniCliente) {
    var url = `../sCarrito/carritoCRUD.php?idCarrito=${idCarrito}&dniCliente=${dniCliente}`;

    fetch(url, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

// Esta función obtiene la cookie ID Carrito

function obtenerIdCarrito() {
    var todasLasCookies = document.cookie;
    var cookies = todasLasCookies.split(';');
    var idCarrito = null;

    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i].trim();
        var partes = cookie.split('=');
        var nombre = partes[0];
        var valor = decodeURIComponent(partes[1]);

        if (nombre === 'idCarrito') {
            idCarrito = valor;
            break;
        }
    }

    return idCarrito;
}