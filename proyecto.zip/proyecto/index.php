<?php
$base_url = "/PROYECTO";
$request_uri = $_SERVER['REQUEST_URI'];
if ($request_uri === $base_url . "/index.php") {
    header("Location: " . $base_url . "/html/index.html");
    exit();
}
?>