<?php

const BASE='virtualmarket';
const HOST='localhost';
const USUARIO ='root';
const PASS='';
const OPCIONES = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET
NAMES utf8", PDO::ATTR_ERRMODE =>
PDO::ERRMODE_EXCEPTION,PDO::ATTR_PERSISTENT =>true);

?>