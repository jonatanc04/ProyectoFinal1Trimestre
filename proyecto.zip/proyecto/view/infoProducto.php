<?php

echo "<div id='infProd' class='col-12 col-sm-6'>";
echo "<p>Nombre: " . $dato['nombre'] . "</p>";
echo "<p>Marca: " . $dato['marca'] . "</p>";
echo "<p>Precio: " . $dato['precio'] . "€</p><br>";
echo "<p class='descDeProd'>" . $dato['origen'] . "</p><br>";

echo '<form action="" method="post">';
echo '<p class="cantidad-label">Cantidad: </p><input type="number" name="cantidad" value="1">';
echo '<button type="submit" name="comprar" class="boton-comprar">Comprar</button>';
echo '</form>';

echo "</div>";

echo "<div id='imgPr' class='col-12 col-sm-6'>";
echo "<img src='../view/img/" . $dato['foto'] . "'>";
echo "</div>";

echo "</div>";