<?php

foreach ($dato as $fila) {
    echo "<a href='detalle.php?idProducto=" . $fila['idProducto'] . "' class='goProduct' href='details.html'>";
    echo "<div class='prod'>";
    echo "<img class='prodView' src='../view/img/" . $fila['foto'] . "'>";
    echo "<p class='prodName'>" . $fila['nombre'] . "</p>";
    echo "</div>";
    echo "</a>";
}