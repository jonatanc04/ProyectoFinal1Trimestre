<?php
include "../config/autocarga.php";
$base = new Base();

include "../view/header.php";

echo "<div id='body' class='row'>";
if (isset($_POST['comprar'])) {
    $idProducto = $_GET['idProducto'];
    $cantidad = $_POST['cantidad'];

    if (isset($_COOKIE['idCarrito'])) {
        if (isset($_COOKIE['dniCliente'])) {
            $carrito = new Carrito($_COOKIE['idCarrito'], $_COOKIE['dniCliente'], $idProducto, $cantidad);
            $carrito->insertarProducto($base->link);
        } else {
            $carrito = new Carrito($_COOKIE['idCarrito'], '', $idProducto, $cantidad);
            $carrito->insertarProducto($base->link);
        }
    } else {
        $idCarrito = uniqid();
        setcookie('idCarrito', $idCarrito, time() + 3600, '/');
        if (isset($_COOKIE['dniCliente'])) {
            $carrito = new Carrito($idCarrito, $_COOKIE['dniCliente'], $idProducto, $cantidad);
            $carrito->insertarProducto($base->link);
        } else {
            $carrito = new Carrito($idCarrito, '', $idProducto, $cantidad);
            $carrito->insertarProducto($base->link);
        }
    }

    header("Location: verCarrito.php?idProducto=$idProducto&cantidad=$cantidad");
    exit;
}

$url = "http://localhost/proyecto/sProductos/obtenerProductos.php?idProducto=" . $_GET['idProducto'];
$context = stream_context_create(array(
    'http' => array(
        'method' => 'GET',
        'header' => "User-Agent: PHP\r\n",
        'ignore_errors' => true,
    )
));

$dato = file_get_contents($url, false, $context);
$dato = json_decode($dato, true);

include "../view/infoProducto.php";

include "../view/footer.html";
?>