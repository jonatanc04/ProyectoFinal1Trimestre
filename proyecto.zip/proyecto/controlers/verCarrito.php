<?php

include "../config/autocarga.php";
include "../view/header.php";
$base = new Base();

echo "<div id='body' class='row'>";
echo "<div id='prodConten'>";
echo "<script src='../js/gestionCarrito.js'></script>";
echo "</div>";
echo "</div>";

include "../view/footer.html";

?>