<?php

include "../view/header.php";

echo "<div id='body' class='row'>";
echo "<div class='productosCont'>";
                    
    $url = "http://localhost/proyecto/sProductos/obtenerProductos.php";
    $context = stream_context_create(array(
        'http' => array(
            'method' => 'GET',
            'header' => "User-Agent: PHP\r\n",
            'ignore_errors' => true,
        )
    ));
    
    $dato = file_get_contents($url, false, $context);
    $dato = json_decode($dato, true);
        
    include "../view/verProductos.php";
                
echo "</div>";
echo "</div>";

include "../view/footer.html";

?>