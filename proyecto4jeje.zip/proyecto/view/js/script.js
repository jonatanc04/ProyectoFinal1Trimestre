let singUp = document.getElementById("singUp");
let singIn = document.getElementById("singIn");
let nameInput = document.getElementById("nameInput");
let dniInput = document.getElementById("dniInput");
let title = document.getElementById("title");

singIn.onclick = function () {
    nameInput.style.maxHeight = "0vw";
    dniInput.style.maxHeight = "0vw";
    title.innerHTML = "Log In";
    singIn.classList.add("disable");
    singUp.classList.remove("disable");
}

singUp.onclick = function () {
    nameInput.style.maxHeight = "2vw";
    dniInput.style.maxHeight = "2vw";
    title.innerHTML = "Registro";
    singUp.classList.add("disable");
    singIn.classList.remove("disable");
}