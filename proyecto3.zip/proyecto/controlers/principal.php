<?php

include "../html/header.html";

echo "<div class='productosCont'>";

                
    $dato = json_decode(file_get_contents("http://localhost/proyecto/sProductos/obtenerProductos.php"));
    var_dump($dato);
    foreach ($dato as $fila) {
        echo "<a href='producto.php?idProducto=" . $fila['idProducto'] . "' class='goProduct' href='details.html'>";
        echo "<div class='prod'>";
        echo "<img class='prodView' src='img/" . $fila['foto'] . "'>";
        echo "<p class='prodName'>" . $fila['nombre'] . "</p>";
        echo "</div>";
        echo "</a>";
    }

                
echo "</div>";

include "../html/footer.html";

?>